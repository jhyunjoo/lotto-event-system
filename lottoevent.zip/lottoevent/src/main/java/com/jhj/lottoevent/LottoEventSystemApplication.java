package com.jhj.lottoevent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LottoEventSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LottoEventSystemApplication.class, args);
	}

}
